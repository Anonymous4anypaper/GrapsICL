python motivation.py --task poem_sentiment
python motivation.py --task climate_fever
python motivation.py --task medical_questions_pairs
python motivation.py --task glue-mrpc