from setuptools import setup

setup(
    name='Gradient-free',
    version='0.1',
    packages=[''],
    package_dir={'': 'src'},
    url='',
    license='',
    author='Ziniu Zhang',
    author_email='zhang.zini@northeastern.edu',
    description=''
)