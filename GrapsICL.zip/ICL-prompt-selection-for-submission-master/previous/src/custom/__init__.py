"""
Custom experiment source code (using GPUs, not OpenAI APIs)
"""