from oai.utils.api_wrapper import fetch_model_ids


def main():
    fetch_model_ids()


if __name__ == '__main__':
    main()
