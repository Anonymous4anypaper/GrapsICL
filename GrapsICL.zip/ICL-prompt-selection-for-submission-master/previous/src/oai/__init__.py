"""
OpenAI experiment source code
"""