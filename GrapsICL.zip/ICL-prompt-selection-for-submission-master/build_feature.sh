mkdir ./features

python get_feature.py

python get_feature.py --task climate_fever

python get_feature.py --task glue-rte

python get_feature.py --task glue-wnli

python get_feature.py --task poem_sentiment

