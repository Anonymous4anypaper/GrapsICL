python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --forsel --m 2 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --forsel --m 3 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --forsel --m 4 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --forsel --m 5 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --forsel --m 6 --device 1


python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --forsel --m 2 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --forsel --m 3 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --forsel --m 4 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --forsel --m 5 --device 1

python test.py --dataset medical_questions_pairs --gpt2 meta-llama/Llama-3.2-3B --method direct --out_dir out/meta-llama-Llama-3.2-3B --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --forsel --m 6 --device 1

