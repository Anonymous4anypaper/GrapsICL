python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --ranens --m 2 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --ranens --m 3 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --ranens --m 4 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --ranens --m 5 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 10 --ranens --m 6 --device 1


python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --ranens --m 2 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --ranens --m 3 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --ranens --m 4 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --ranens --m 5 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 100 --k 15 --ranens --m 6 --device 1


# --------------------------------------


python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 10 --ranens --m 2 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 10 --ranens --m 3 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 10 --ranens --m 4 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 10 --ranens --m 5 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 10 --ranens --m 6 --device 1


python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 15 --ranens --m 2 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 15 --ranens --m 3 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 15 --ranens --m 4 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 15 --ranens --m 5 --device 1

python test.py --dataset poem_sentiment --gpt2 gpt2-large --method direct --out_dir out/gpt2-large --do_zeroshot --test_batch_size 4 --use_demonstrations  --seed 200 --k 15 --ranens --m 6 --device 1


